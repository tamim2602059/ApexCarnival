# APEX CARNIVAL - Android APK (Codemagic + Capacitor)

Repo root has only two files: `codemagic.yaml` and `app.zip`.
Codemagic unzips `app.zip`, installs npm packages (Capacitor, three@0.128.0, Inter font),
creates the Android project with `npx cap add android`, patches it with `prepare-android.sh`
and builds a debug APK (`assembleDebug`).

Update the game: replace `index.html` inside `app.zip`, upload the new `app.zip`, run the build again.
APK appears under Artifacts on the Codemagic build page.
