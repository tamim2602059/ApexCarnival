#!/usr/bin/env bash
# Runs after `npx cap add android`, before `npx cap sync android`.
set -euo pipefail
cd "$(dirname "$0")"
APP=android/app/src/main
MAN=$APP/AndroidManifest.xml

[ -f "$MAN" ] || { echo "ERROR: $MAN not found - did 'npx cap add android' run?"; exit 1; }

# 1) landscape-only (sensor based, both landscape directions)
if ! grep -q 'screenOrientation' "$MAN"; then
  sed -i '0,/android:name="\.MainActivity"/s//android:name=".MainActivity" android:screenOrientation="sensorLandscape"/' "$MAN"
fi
grep -q 'sensorLandscape' "$MAN" || { echo "ERROR: could not set sensorLandscape"; cat "$MAN"; exit 1; }

# 2) launcher icons
rm -rf .icons_tmp && mkdir .icons_tmp
unzip -oq icons.zip -d .icons_tmp 2>/dev/null || python3 -m zipfile -e icons.zip .icons_tmp
cp -r .icons_tmp/mipmap-* "$APP/res/"
rm -rf .icons_tmp

# 3) adaptive icon background colour
BG=$APP/res/values/ic_launcher_background.xml
if [ -f "$BG" ]; then
  sed -i 's/#FFFFFF/#0B0C16/I' "$BG"
else
  echo "WARN: $BG not found (icon background left as default)"
fi

# 4) MainActivity.java: keep the package line, replace the rest
JAVA=$(find "$APP/java" -name MainActivity.java | head -n 1)
[ -n "$JAVA" ] || { echo "ERROR: MainActivity.java not found"; exit 1; }
PKG=$(grep -m 1 '^package ' "$JAVA")
{ echo "$PKG"; echo; cat MainActivity.body.java; } > "$JAVA"

echo "prepare-android.sh OK  ($PKG)"
