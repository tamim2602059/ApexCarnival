#!/usr/bin/env bash
# Runs after `npx cap add android`: icon, splash, landscape, fullscreen.
set -e
RES=android/app/src/main/res
MAIN=android/app/src/main

# 1) Icons (adaptive + legacy) and dark splash
rm -f $RES/drawable-v24/ic_launcher_foreground.xml
rm -f $RES/mipmap-*/ic_launcher*.png $RES/mipmap-anydpi-v26/ic_launcher*.xml
cp -r resources/android/res/* $RES/
find $RES -name 'splash.png' ! -path "$RES/drawable/splash.png" -exec cp resources/android/res/drawable/splash.png {} \;

# 2) Fullscreen + cutout in the app theme
sed -i '/name="AppTheme.NoActionBar"/,/<\/style>/ s#</style>#        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>\n    </style>#' $RES/values/styles.xml

# 3) Landscape only (game is landscape)
sed -i 's#<activity#<activity android:screenOrientation="sensorLandscape"#' $MAIN/AndroidManifest.xml

# 4) Immersive MainActivity
cp resources/android/java/MainActivity.java $MAIN/java/com/apexcarnival/game/MainActivity.java

echo "Android project prepared."
