#!/usr/bin/env bash
# Runs after `npx cap add android`: landscape, fullscreen, icon, keep-screen-on.
set -e
RES=android/app/src/main/res
MAN=android/app/src/main/AndroidManifest.xml

# 1) landscape (sensor based, both directions)
if ! grep -q screenOrientation "$MAN"; then
  sed -i '0,/<activity/s//<activity android:screenOrientation="sensorLandscape"/' "$MAN"
fi

# 2) custom launcher icon
rm -rf /tmp/apex-icons && mkdir -p /tmp/apex-icons
unzip -oq icons.zip -d /tmp/apex-icons
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$d"
  cp -f /tmp/apex-icons/mipmap-$d/*.png "$RES/mipmap-$d/"
done
if [ -f "$RES/values/ic_launcher_background.xml" ]; then
  sed -i 's|#FFFFFF|#0B0C16|I' "$RES/values/ic_launcher_background.xml"
fi

# 3) fullscreen immersive + keep screen on (MainActivity)
MA=$(find android/app/src/main/java -name MainActivity.java | head -1)
PKG=$(grep -m1 '^package ' "$MA")
{ echo "$PKG"; echo; cat MainActivity.body.java; } > "$MA"

echo "Android project prepared."
