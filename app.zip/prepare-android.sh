#!/usr/bin/env bash
# Runs after `npx cap add android`, before `npx cap sync android`. Works on macOS and Linux.
set -euo pipefail
cd "$(dirname "$0")"
APP=android/app/src/main
MAN=$APP/AndroidManifest.xml
[ -f "$MAN" ] || { echo "ERROR: $MAN not found - did 'npx cap add android' run?"; exit 1; }

# 1) landscape-only
python3 - "$MAN" <<'PY'
import sys
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
if 'screenOrientation' not in s:
    assert s.count('android:name=".MainActivity"')==1, 'MainActivity tag not found'
    s=s.replace('android:name=".MainActivity"','android:name=".MainActivity" android:screenOrientation="sensorLandscape"')
    open(p,'w',encoding='utf-8').write(s)
PY
grep -q 'sensorLandscape' "$MAN" || { echo "ERROR: sensorLandscape not set"; exit 1; }

# 2) launcher icons
rm -rf .icons_tmp && mkdir .icons_tmp
unzip -oq icons.zip -d .icons_tmp 2>/dev/null || python3 -m zipfile -e icons.zip .icons_tmp
cp -R .icons_tmp/mipmap-* "$APP/res/"
rm -rf .icons_tmp

# 3) adaptive icon background colour
BG=$APP/res/values/ic_launcher_background.xml
if [ -f "$BG" ]; then
  python3 - "$BG" <<'PY'
import sys,re
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
open(p,'w',encoding='utf-8').write(re.sub('#ffffff','#0B0C16',s,flags=re.I))
PY
else
  echo "WARN: $BG not found"
fi

# 4) MainActivity.java: keep package line, replace the rest
JAVA=$(find "$APP/java" -name MainActivity.java | head -n 1)
[ -n "$JAVA" ] || { echo "ERROR: MainActivity.java not found"; exit 1; }
PKG=$(grep -m 1 '^package ' "$JAVA")
{ echo "$PKG"; echo; cat MainActivity.body.java; } > "$JAVA"
echo "prepare-android.sh OK  ($PKG)"
