# APEX CARNIVAL - Android APK (Capacitor + Codemagic)

1. Create a GitHub repo and upload everything from this zip to the repo ROOT
   (`codemagic.yaml` must be in the root). Branch: `main`.
2. Go to https://codemagic.io -> Add application -> GitHub -> pick the repo
   -> choose "codemagic.yaml" configuration.
3. Start build -> workflow "APEX CARNIVAL - Android APK".
4. Download `app-debug.apk` from the build's Artifacts, install on your phone
   (allow "Install unknown apps").

Game files: `www/index.html` + `www/three.min.js` (works offline).
Icon: `resources/` (made from your screenshot). Package id: com.apexcarnival.game
