# APEX CARNIVAL (Android APK via Codemagic)

Sob file repository-r root-e thakbe (kono folder lagbe na).
Codemagic nijei www folder, Android project, icon, landscape, fullscreen shob baniye `.apk` dey.

1. Ei file gulo GitHub repository-te upload koro.
2. codemagic.io > Add application > ei repository > `codemagic.yaml` workflow > Start new build.
3. Build shesh hole Artifacts theke `app-debug.apk` download kore phone-e install koro.
